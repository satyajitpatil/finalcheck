package com.cognizant.movieapp.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.truyum.dao.CartDao;
import com.cognizant.truyum.dao.CartDaoCollectionImpl;
import com.cognizant.truyum.model.MenuItem;

/**
* Servlet implementation class ShowCartServlet
*/
@WebServlet("/ShowCartServlet")
public class ShowFavoriteServlet extends HttpServlet {
                private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowFavoriteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

                /**
                * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
                */
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                                CartDao cd = new CartDaoCollectionImpl();
                                List<MenuItem> lm = null;
                                long id = 1;
                                try
                                {
                                                lm = cd.getAllCartItems(id);
                                                double sum = 0.0;
                                                for(MenuItem m:lm)
                                                {
                                                                sum += m.getPrice();
                                                }
                                                request.setAttribute("sum", sum);
                                                request.setAttribute("menuItem", lm);
                                                request.setAttribute("EmptyMsg", "No items in cart");
                                                RequestDispatcher rd = request.getRequestDispatcher("cart.jsp");
                                                rd.forward(request, response);
                                }catch(Exception e)
                                {
                                                
                                }

                }

}
