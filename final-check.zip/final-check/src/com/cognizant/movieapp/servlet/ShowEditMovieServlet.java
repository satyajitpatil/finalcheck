package com.cognizant.movieapp.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.movieapp.dao.MovieDao;
import com.cognizant.movieapp.dao.MovieDaoCollectionImpl;
import com.cognizant.movieapp.model.Movie;



/**
 * Servlet implementation class ShowEditMenuItemServlet
 */
@WebServlet("/ShowEditMovieServlet")
public class ShowEditMovieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ShowEditMovieServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rdMenu =request.getRequestDispatcher("edit-movie.jsp");
		MovieDao moviedao = new MovieDaoCollectionImpl();
		long movieid = Integer.parseInt(request.getParameter("movieId"));
		Movie mi = moviedao.getMovie(movieid);
		request.setAttribute("movie", mi);
		rdMenu.forward(request,response);
	}

}
