package com.cognizant.movieapp.dao;

import java.util.List;

import com.cognizant.movieapp.model.Movie;

public class MovieDaoSqlImpl implements MovieDao {

	public MovieDaoSqlImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<Movie> getMovieListAdmin() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Movie> getMovieListCustomer() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifyMovie(Movie movie) {
		// TODO Auto-generated method stub
	}

	@Override
	public Movie getMovie(long movieId) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
