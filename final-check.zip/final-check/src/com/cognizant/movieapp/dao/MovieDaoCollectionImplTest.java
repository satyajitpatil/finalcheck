package com.cognizant.movieapp.dao;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.movieapp.model.Movie;

public class MovieDaoCollectionImplTest {

	private MovieDao moviedao;
	@Before
	public void setUp() throws Exception {
		moviedao = new MovieDaoCollectionImpl();
	}

	@After
	public void tearDown() throws Exception {
		moviedao = null;
	}

	@Test
	public final void testMovieDaoCollectionImpl() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetMovieListAdmin() {
		List<Movie> menuitemlist = null;
		try{
			menuitemlist = moviedao.getMovieListAdmin();
		}catch(Exception e){
			e.printStackTrace();
		}
		for(Movie mi : menuitemlist){
			System.out.println(mi);
		}
		assertTrue(menuitemlist.size()>0);
	}

	@Test
	public final void testGetMovieListCustomer() {
		fail("Not yet implemented");
	}

	@Test
	public final void testModifyMovie() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetMovie() {
		fail("Not yet implemented");
	}

}
