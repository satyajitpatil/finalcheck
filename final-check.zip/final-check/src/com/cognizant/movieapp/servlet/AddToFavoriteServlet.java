package com.cognizant.movieapp.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.movieapp.dao.FavoriteDao;
import com.cognizant.movieapp.dao.FavoriteDaoCollectionImpl;
import com.cognizant.movieapp.dao.MovieDao;
import com.cognizant.movieapp.dao.MovieDaoCollectionImpl;
import com.cognizant.movieapp.model.Movie;

/**
* Servlet implementation class AddToCartServlet
*/
@WebServlet("/AddToCartServlet")
public class AddToFavoriteServlet extends HttpServlet {
                private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToFavoriteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

                /**
                * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
                */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        List<Movie> movieList = null;
        MovieDao movieDao = null;
        movieDao =  new MovieDaoCollectionImpl();
        RequestDispatcher rDispatcher = request
                     .getRequestDispatcher("movie-list-customer.jsp");
        long userId = 1;
        long movieId = Long.parseLong(request.getParameter("movieId"));
        FavoriteDao cartDao = new FavoriteDaoCollectionImpl();
        cartDao.addMovie(userId, movieId);
        movieList = movieDao.getMovieListCustomer();
        request.setAttribute("msg", "Item Added Succesfully");
        request.setAttribute("addCartStatus", true);
        request.setAttribute("movie", movieList);
        rDispatcher.forward(request, response);
        
 }



}
