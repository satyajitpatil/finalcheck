package com.cognizant.movieapp.dao;

import java.util.List;

import com.cognizant.movieapp.model.Movie;

public interface FavoriteDao {
	void addMovie( long userId, long movieId);
	List<Movie>getAllMovies(long userId) throws FavoriteEmptyException;
	void removeMovie(long userId, long movieId);
}
