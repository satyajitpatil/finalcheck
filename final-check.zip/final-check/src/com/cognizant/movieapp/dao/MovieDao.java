package com.cognizant.movieapp.dao;

import java.util.List;

import com.cognizant.movieapp.model.Movie;

public interface MovieDao {
	List<Movie>getMovieListAdmin();
	List<Movie>getMovieListCustomer();
	void modifyMovie(Movie movie);
	Movie getMovie(long movieId);

}
