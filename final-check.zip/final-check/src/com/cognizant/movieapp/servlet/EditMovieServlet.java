package com.cognizant.movieapp.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cognizant.movieapp.dao.MovieDao;
import com.cognizant.movieapp.dao.MovieDaoCollectionImpl;
import com.cognizant.movieapp.model.Movie;
import com.cognizant.movieapp.util.DateUtil;



/**
 * Servlet implementation class EditMovieServlet
 */
@WebServlet("/EditMovieServlet")
public class EditMovieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public EditMovieServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		MovieDao MovieDao = new MovieDaoCollectionImpl();
		Movie Movie = new Movie();
		Movie.setId((long) Integer.parseInt(request.getParameter("movieId")));
		Movie.setMovieName(request.getParameter("moviename"));
		Movie.setBoxOffice(Long.parseLong(request.getParameter("earnings")));
		Movie.setActive(Boolean.parseBoolean(request.getParameter("branch")));
		Movie.setGenre(request.getParameter("genre"));
		Movie.setDateOfLaunch(DateUtil.convertToDate(request.getParameter("date-of-lauch")));
		Movie.setHasTeaser((Boolean.parseBoolean(request.getParameter("HasTeaser"))));

		MovieDao.modifyMovie(Movie);

		RequestDispatcher rd = request.getRequestDispatcher("edit-movie-status.jsp");
		rd.forward(request, response);
	}

}
