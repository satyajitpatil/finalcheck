package com.cognizant.movieapp.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cognizant.movieapp.model.Movie;
import com.cognizant.movieapp.util.DateUtil;

public class MovieDaoCollectionImpl implements MovieDao {

	private static List<Movie> movieList = null;
	
	public MovieDaoCollectionImpl() {
		if(movieList == null){
			movieList = new ArrayList<Movie>();
			Movie mi1 = new Movie(1,"Angers:Endgame",2345678789L,true,DateUtil.convertToDate("27/04/2019"),"Superhero",true);
			Movie mi2 = new Movie(2,"Jurassic Park",2345678789L,true,DateUtil.convertToDate("27/04/2019"),"Science Fiction",true);			
			movieList.add(mi1);
			movieList.add(mi2);
		}
	}

	@Override
	public List<Movie> getMovieListAdmin() {
		// TODO Auto-generated method stub
		return movieList;
	}

	@Override
	public List<Movie> getMovieListCustomer() {
		// TODO Auto-generated method stub
		 List<Movie> movieListCustomer = new ArrayList<>();
	        Date today = new Date();
	        for (Movie movie : movieList) {
	             if ((movie.getDateOfLaunch().compareTo(today)) <= 0) {
	                  if (movie.isActive()) {
	                	  movieListCustomer.add(movie);
	                  }
	             }
	        }
		return movieListCustomer;
	}

	@Override
	public void modifyMovie(Movie movie) {
		// TODO Auto-generated method stub
		 movieList.set((int) movie.getId() - 1, movie);
		 System.out.println(getMovie(movie.getId()));
	}

	@Override
	public Movie getMovie(long movieId) {
		// TODO Auto-generated method stub
		Movie movie = null;
		for(Movie m: movieList){
			if(m.getId()==movieId){
				movie = m;
			}
		}
		return movie;
	}
	
	

	

	

}
