package com.cognizant.movieapp.model;

import java.util.List;

public class Favorite {

	private List<Movie> movieList;
	private int noOfFav;
	
	public Favorite() {
		super();
	}

	

	public List<Movie> getMovieList() {
		return movieList;
	}



	public void setMovieList(List<Movie> movieList) {
		this.movieList = movieList;
	}



	public int getNoOfFav() {
		return noOfFav;
	}



	public void setNoOfFav(int noOfFav) {
		this.noOfFav = noOfFav;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((movieList == null) ? 0 : movieList.hashCode());
		long temp;
		temp = Double.doubleToLongBits(noOfFav);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Favorite other = (Favorite) obj;
		if (movieList == null) {
			if (other.movieList != null)
				return false;
		} else if (!movieList.equals(other.movieList))
			return false;
		if (Double.doubleToLongBits(noOfFav) != Double.doubleToLongBits(other.noOfFav))
			return false;
		return true;
	}
	
	
}
