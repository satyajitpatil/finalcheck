package com.cognizant.movieapp.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class FavoriteDaoCollectionImplTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public final void testFavoriteDaoCollectionImpl() {
		fail("Not yet implemented");
	}

	@Test
	public final void testAddMovie() {
		fail("Not yet implemented");
	}

	@Test
	public final void testGetAllMovies() {
		fail("Not yet implemented");
	}

	@Test
	public final void testRemoveMovie() {
		fail("Not yet implemented");
	}

}
