package com.cognizant.movieapp.dao;

public class FavoriteEmptyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6632178060924659372L;

	public FavoriteEmptyException() {
		// TODO Auto-generated constructor stub
	}

	public FavoriteEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FavoriteEmptyException(Throwable message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public FavoriteEmptyException(String message, Throwable arg1) {
		super(message, arg1);
		// TODO Auto-generated constructor stub
	}

	public FavoriteEmptyException(String message, Throwable arg1, boolean arg2, boolean arg3) {
		super(message, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
