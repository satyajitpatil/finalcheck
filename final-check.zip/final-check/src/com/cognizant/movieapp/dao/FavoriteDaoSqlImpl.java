package com.cognizant.movieapp.dao;

import java.util.List;

import com.cognizant.movieapp.model.Movie;

public class FavoriteDaoSqlImpl implements FavoriteDao {

	public FavoriteDaoSqlImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addMovie(long userId, long movieId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Movie> getAllMovies(long userId) throws FavoriteEmptyException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeMovie(long userId, long movieId) {
		// TODO Auto-generated method stub
		
	}

	

}
